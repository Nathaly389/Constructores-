# Implementación de Constructores en Java

**Nombre:** Nathaly Cabrera

## 📌 Descripción
Este proyecto muestra el uso de:
- Constructor por defecto
- Constructor parametrizado
- Sobrecarga de constructores

Se crea una clase `Persona` y se prueban sus constructores desde la clase principal `Main`.

## ▶️ Ejemplo de salida

```
Nombre: Sin nombre, Edad: 0  
Nombre: Nathaly, Edad: 22  
Nombre: Carlos, Edad: 18
```
