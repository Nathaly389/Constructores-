public class Persona {
    private String nombre;
    private int edad;

    // Constructor por defecto
    public Persona() {
        this.nombre = "Sin nombre";
        this.edad = 0;
    }

    // Constructor parametrizado
    public Persona(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    // Sobrecarga de constructor (solo nombre)
    public Persona(String nombre) {
        this.nombre = nombre;
        this.edad = 18; // edad por defecto
    }

    public void mostrarInformacion() {
        System.out.println("Nombre: " + this.nombre + ", Edad: " + this.edad);
    }
}
